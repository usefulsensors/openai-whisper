### How to use Whisper TFLIte using TF Lite C++ library in Android projects

This repo is an example that transcribe audio using whisper.tflite model in Android projects
 
